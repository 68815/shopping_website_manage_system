# Vision of QXlsx

- prepare the QtExcel library for Qt6. (or use only in Qt5)

## Qt6Excel

- cmake support (change main maker)
- based on modern C++(C++17) and new compiler




