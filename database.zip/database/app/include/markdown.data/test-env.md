Test Environment is below.
    Qt 5.9.2 (MingW/Windows 32bit)
    Qt 5.9.1 (Visual Studio 2017/Windows 64bit)
    Qt 5.9.1 (Visual Studio 2017/Windows 32bit)
    Qt 5.9.1 (MingW/Windows 32bit)
    Qt 5.9.1 (Ubuntu 16/Linux x64)
    Qt 5.6.0 (MingW/Windows 32bit)
    Qt 5.5.1 (MingW/Windows 32bit)
    Qt 5.5.0 (Ubuntu 17/Linux i686)
    Qt 5.2.0 (Ubuntu 14/Linux x64)
    Qt 5.0.1 (MingW/Windows 32bit)

